xSky.dll for Tribes 1.40/1.41
Version 0.5
By Smokey

=======================================================================================================
About
=======================================================================================================
Plugin that renders a cubic skybox in-game with the following functions:

    - xSky::Enable();
    - xSky::Disable();
    - xSky::setDML(%dmlFileName);
    - xSky::getDML();
    - xSky::setRotation(%rotation);
    - xSky::getRotation();
    - xSky::setSpeed(%speed);
    - xSky::getSpeed();

The plugin renders a cubic skybox by modifying native Tribes rendering code.
This does NOT rely on an OpenGL overlay or other approach that may have additional performance overhead.

=======================================================================================================
Details
=======================================================================================================

    xSky::Enable
-------------------------------------------------------------------------------------------------------
    Render the current sky as a skybox instead of a skyband.

    xSky::Disable() - Returns the rendering of the sky to a skyband.



    xSky::setDML(%dmlFileName)
-------------------------------------------------------------------------------------------------------
    Changes the sky texture file in-game.

    Parameters:
        %dmlFileName - File name of the Tribe's material list file for the sky (.dml)

    Example:
        - xSky::setDML("litesky.dml");
        - xSky::setDML("lushdayclear.dml");

    Note: If the .dml file is in a volume (e.g., LushWorld.zip), that volume must be loaded.

    xSky::getDML() - Returns the current sky texture .dml file.



    xSky::setRotation(%rotation)
-------------------------------------------------------------------------------------------------------
    Set the rotation of the sky.

    Parameters:
        %rotation - Rotation in degrees of the sky. Values from 0 to 360.

    Example:
        - xSky::setRotation(45);

    xSky::getRotation() - Returns the current sky rotation.



    xSky::setSpeed(%speed)
-------------------------------------------------------------------------------------------------------
    Sets the rotation speed of the sky.

    Parameters:
        %speed - Rotation speed of the sky. Values from 0 to 100 are reasonable (can be negative). (Default: 0)

    Example:
        - xSky::setSpeed(20);

    xSky::getSpeed() - Returns the current rotation speed.
