// xFont.dll Test HUD
// By Smokey
// 0.5

function xFontTest::Init() {
	if ( $xFontTest::Loaded )
		return;
	$xFontTest::Loaded = true;

    // =================================================================================================

    HUD::New::Shaded("xFontTest::Container1", 100, 100, 400, 830, xFontTest::Wake, xFontTest::Sleep);
    newObject("xFontTest::Title1_1", FearGuiFormattedText, 0, 20, 400, 30);
    HUD::Add("xFontTest::Container1", "xFontTest::Title1_1");
    newObject("xFontTest::Font1_1", FearGuiFormattedText, 0, 60, 400, 50);
    HUD::Add("xFontTest::Container1", "xFontTest::Font1_1");

    newObject("xFontTest::Title1_2", FearGuiFormattedText, 0, 130, 400, 30);
    HUD::Add("xFontTest::Container1", "xFontTest::Title1_2");
    newObject("xFontTest::Font1_2", FearGuiFormattedText, 0, 170, 400, 50);
    HUD::Add("xFontTest::Container1", "xFontTest::Font1_2");
    newObject("xFontTest::Font1_3", FearGuiFormattedText, 0, 230, 400, 50);
    HUD::Add("xFontTest::Container1", "xFontTest::Font1_3");
    newObject("xFontTest::Font1_4", FearGuiFormattedText, 0, 290, 400, 50);
    HUD::Add("xFontTest::Container1", "xFontTest::Font1_4");

    newObject("xFontTest::Title1_3", FearGuiFormattedText, 0, 360, 400, 30);
    HUD::Add("xFontTest::Container1", "xFontTest::Title1_3");
    newObject("xFontTest::Font1_5", FearGuiFormattedText, 0, 400, 400, 50);
    HUD::Add("xFontTest::Container1", "xFontTest::Font1_5");
    newObject("xFontTest::Font1_6", FearGuiFormattedText, 0, 460, 400, 50);
    HUD::Add("xFontTest::Container1", "xFontTest::Font1_6");
    newObject("xFontTest::Font1_7", FearGuiFormattedText, 0, 520, 400, 50);
    HUD::Add("xFontTest::Container1", "xFontTest::Font1_7");

    newObject("xFontTest::Title1_4", FearGuiFormattedText, 0, 590, 400, 30);
    HUD::Add("xFontTest::Container1", "xFontTest::Title1_4");
    newObject("xFontTest::Font1_8", FearGuiFormattedText, 0, 630, 400, 50);
    HUD::Add("xFontTest::Container1", "xFontTest::Font1_8");
    newObject("xFontTest::Font1_9", FearGuiFormattedText, 0, 690, 400, 50);
    HUD::Add("xFontTest::Container1", "xFontTest::Font1_9");
    newObject("xFontTest::Font1_10", FearGuiFormattedText, 0, 750, 400, 50);
    HUD::Add("xFontTest::Container1", "xFontTest::Font1_10");

    // =================================================================================================

    HUD::New::Shaded("xFontTest::Container2", 100, 100, 400, 830, xFontTest::Wake, xFontTest::Sleep);
    newObject("xFontTest::Title2_1", FearGuiFormattedText, 0, 20, 400, 30);
    HUD::Add("xFontTest::Container2", "xFontTest::Title2_1");
    newObject("xFontTest::Font2_1", FearGuiFormattedText, 0, 60, 400, 50);
    HUD::Add("xFontTest::Container2", "xFontTest::Font2_1");

    newObject("xFontTest::Title2_2", FearGuiFormattedText, 0, 130, 400, 30);
    HUD::Add("xFontTest::Container2", "xFontTest::Title2_2");
    newObject("xFontTest::Font2_2", FearGuiFormattedText, 0, 170, 400, 50);
    HUD::Add("xFontTest::Container2", "xFontTest::Font2_2");
    newObject("xFontTest::Font2_3", FearGuiFormattedText, 0, 230, 400, 50);
    HUD::Add("xFontTest::Container2", "xFontTest::Font2_3");
    newObject("xFontTest::Font2_4", FearGuiFormattedText, 0, 290, 400, 50);
    HUD::Add("xFontTest::Container2", "xFontTest::Font2_4");

    newObject("xFontTest::Title2_3", FearGuiFormattedText, 0, 360, 400, 30);
    HUD::Add("xFontTest::Container2", "xFontTest::Title2_3");
    newObject("xFontTest::Font2_5", FearGuiFormattedText, 0, 400, 400, 50);
    HUD::Add("xFontTest::Container2", "xFontTest::Font2_5");
    newObject("xFontTest::Font2_6", FearGuiFormattedText, 0, 460, 400, 50);
    HUD::Add("xFontTest::Container2", "xFontTest::Font2_6");
    newObject("xFontTest::Font2_7", FearGuiFormattedText, 0, 520, 400, 50);
    HUD::Add("xFontTest::Container2", "xFontTest::Font2_7");

    newObject("xFontTest::Title2_4", FearGuiFormattedText, 0, 590, 400, 30);
    HUD::Add("xFontTest::Container2", "xFontTest::Title2_4");
    newObject("xFontTest::Font2_8", FearGuiFormattedText, 0, 630, 400, 50);
    HUD::Add("xFontTest::Container2", "xFontTest::Font2_8");
    newObject("xFontTest::Font2_9", FearGuiFormattedText, 0, 690, 400, 50);
    HUD::Add("xFontTest::Container2", "xFontTest::Font2_9");
    newObject("xFontTest::Font2_10", FearGuiFormattedText, 0, 750, 400, 50);
    HUD::Add("xFontTest::Container2", "xFontTest::Font2_10");

    // =================================================================================================

    HUD::New::Shaded("xFontTest::Container3", 100, 100, 400, 830, xFontTest::Wake, xFontTest::Sleep);
    newObject("xFontTest::Title3_1", FearGuiFormattedText, 0, 20, 400, 30);
    HUD::Add("xFontTest::Container3", "xFontTest::Title3_1");
    newObject("xFontTest::Font3_1", FearGuiFormattedText, 0, 60, 400, 50);
    HUD::Add("xFontTest::Container3", "xFontTest::Font3_1");

    newObject("xFontTest::Title3_2", FearGuiFormattedText, 0, 130, 400, 30);
    HUD::Add("xFontTest::Container3", "xFontTest::Title3_2");
    newObject("xFontTest::Font3_2", FearGuiFormattedText, 0, 170, 400, 50);
    HUD::Add("xFontTest::Container3", "xFontTest::Font3_2");
    newObject("xFontTest::Font3_3", FearGuiFormattedText, 0, 230, 400, 50);
    HUD::Add("xFontTest::Container3", "xFontTest::Font3_3");
    newObject("xFontTest::Font3_4", FearGuiFormattedText, 0, 290, 400, 50);
    HUD::Add("xFontTest::Container3", "xFontTest::Font3_4");
    newObject("xFontTest::Font3_5", FearGuiFormattedText, 0, 350, 400, 50);
    HUD::Add("xFontTest::Container3", "xFontTest::Font3_5");

    newObject("xFontTest::Title3_3", FearGuiFormattedText, 0, 420, 400, 30);
    HUD::Add("xFontTest::Container3", "xFontTest::Title3_3");
    newObject("xFontTest::Font3_6", FearGuiFormattedText, 0, 460, 400, 50);
    HUD::Add("xFontTest::Container3", "xFontTest::Font3_6");
    newObject("xFontTest::Font3_7", FearGuiFormattedText, 0, 520, 400, 50);
    HUD::Add("xFontTest::Container3", "xFontTest::Font3_7");
    newObject("xFontTest::Font3_8", FearGuiFormattedText, 0, 580, 400, 50);
    HUD::Add("xFontTest::Container3", "xFontTest::Font3_8");
    newObject("xFontTest::Font3_9", FearGuiFormattedText, 0, 640, 400, 50);
    HUD::Add("xFontTest::Container3", "xFontTest::Font3_9");

    // =================================================================================================

    HUD::New::Shaded("xFontTest::Container4", 100, 100, 400, 830, xFontTest::Wake, xFontTest::Sleep);
    newObject("xFontTest::Title4_1", FearGuiFormattedText, 0, 20, 400, 30);
    HUD::Add("xFontTest::Container4", "xFontTest::Title4_1");
    newObject("xFontTest::Font4_1s", FearGuiFormattedText, 0, 60, 400, 50);
    HUD::Add("xFontTest::Container4", "xFontTest::Font4_1s");
    newObject("xFontTest::Font4_1t", FearGuiFormattedText, 0, 60, 400, 50);
    HUD::Add("xFontTest::Container4", "xFontTest::Font4_1t");
    newObject("xFontTest::Font4_2s", FearGuiFormattedText, 0, 120, 400, 50);
    HUD::Add("xFontTest::Container4", "xFontTest::Font4_2s");
    newObject("xFontTest::Font4_2t", FearGuiFormattedText, 0, 120, 400, 50);
    HUD::Add("xFontTest::Container4", "xFontTest::Font4_2t");

    newObject("xFontTest::Title4_2", FearGuiFormattedText, 0, 190, 400, 30);
    HUD::Add("xFontTest::Container4", "xFontTest::Title4_2");
    newObject("xFontTest::Image4_3", FearGuiFormattedText, 0, 230, 400, 20);
    HUD::Add("xFontTest::Container4", "xFontTest::Image4_3");

    newObject("xFontTest::Title4_3", FearGuiFormattedText, 0, 270, 400, 30);
    HUD::Add("xFontTest::Container4", "xFontTest::Title4_3");
    newObject("xFontTest::Image4_4", FearGuiFormattedText, 0, 310, 400, 20);
    HUD::Add("xFontTest::Container4", "xFontTest::Image4_4");
    newObject("xFontTest::Image4_5", FearGuiFormattedText, 0, 340, 400, 20);
    HUD::Add("xFontTest::Container4", "xFontTest::Image4_5");
    newObject("xFontTest::Image4_6", FearGuiFormattedText, 0, 370, 400, 20);
    HUD::Add("xFontTest::Container4", "xFontTest::Image4_6");

    //newObject("xFontTest::Title4_4", FearGuiFormattedText, 0, 410, 400, 30);
    //HUD::Add("xFontTest::Container4", "xFontTest::Title4_4");
    newObject("xFontTest::Title4_4", FearGuiFormattedText, 43, 440, 75, 30);
    HUD::Add("xFontTest::Container4", "xFontTest::Title4_4");
    newObject("xFontTest::Title4_5", FearGuiFormattedText, 161, 440, 196, 30);
    HUD::Add("xFontTest::Container4", "xFontTest::Title4_5");

    newObject("xFontTest::Image4_7", FearGuiFormattedText, 43, 480, 75, 100);
    HUD::Add("xFontTest::Container4", "xFontTest::Image4_7");
    newObject("xFontTest::Image4_8", FearGuiFormattedText, 161, 480, 75, 100);
    HUD::Add("xFontTest::Container4", "xFontTest::Image4_8");
    newObject("xFontTest::Image4_9", FearGuiFormattedText, 279, 480, 75, 100);
    HUD::Add("xFontTest::Container4", "xFontTest::Image4_9");

    // =================================================================================================

    $xFontTest::Timer1 = xFont::NewTimer("xFontTest::Timer1", 0, 255, 25, 0.01, 0, true);
    $xFontTest::Timer2 = xFont::NewTimer("xFontTest::Timer2", 0, 255, 5, 0.01, 1);
    $xFontTest::Timer3 = xFont::NewTimer("xFontTest::Timer3", 0, 255, 1, 1, 2);
    $xFontTest::Timer4 = xFont::NewTimer("xFontTest::Timer4", 0, 255, 30, 0.05, 3);

    $xFontTest::Timer5 = xFont::NewTimer("xFontTest::Timer5", 255, 0, 25, 0.01, 0, true);
    $xFontTest::Timer6 = xFont::NewTimer("xFontTest::Timer6", 255, 0, 5, 0.01, 1, true);
    $xFontTest::Timer7 = xFont::NewTimer("xFontTest::Timer7", 255, 0, 255, 1, 2, true);
    $xFontTest::Timer8 = xFont::NewTimer("xFontTest::Timer8", 255, 0, 25, 0.1, 3);

    xFont::StartTimer("xFontTest::Timer2");
    xFont::StartTimer("xFontTest::Timer3");

	xFontTest::Reset();
}

function xFontTest::Wake() { xFontTest::Update(); }
function xFontTest::Sleep() { }

function xFontTest::Reset() {
	xFontTest::Update();
}

function xFontTest::Update() {

    // =================================================================================================

    Control::SetValue( "xFontTest::Title1_1", "<jc><f:Roboto-Regular-20.pft:FFFFFF>Original Font");
    Control::SetValue( "xFontTest::Font1_1", "<jc><f:Quantico-Bold-60.pft>Font Test");

    Control::SetValue( "xFontTest::Title1_2", "<jc><f:Roboto-Regular-20.pft:FFFFFF>Change Color");
    Control::SetValue( "xFontTest::Font1_2", "<jc><f:Quantico-Bold-60.pft:9acd32>Font Test");
    Control::SetValue( "xFontTest::Font1_3", "<jc><f:Quantico-Bold-60.pft:ffa500>Font Test");
    Control::SetValue( "xFontTest::Font1_4", "<jc><f:Quantico-Bold-60.pft:1e90ff>Font Test");

    Control::SetValue( "xFontTest::Title1_3", "<jc><f:Roboto-Regular-20.pft:FFFFFF>Add Background");
    Control::SetValue( "xFontTest::Font1_5", "<jc><f:Quantico-Bold-60.pft:FFFFFF:9acd32:3,3>Font Test");
    Control::SetValue( "xFontTest::Font1_6", "<jc><f:Quantico-Bold-60.pft:FFFFFF:ffa500:3,3>Font Test");
    Control::SetValue( "xFontTest::Font1_7", "<jc><f:Quantico-Bold-60.pft:FFFFFF:1e90ff:3,3>Font Test");

    Control::SetValue( "xFontTest::Title1_4", "<jc><f:Roboto-Regular-20.pft:FFFFFF>Multi-Color");
    Control::SetValue( "xFontTest::Font1_8", "<jc><f:Quantico-Bold-60.pft:037e8b:a8cacc:4,4>Font Test");
    Control::SetValue( "xFontTest::Font1_9", "<jc><f:Quantico-Bold-60.pft:94a9fd:0368ff:4,4>Font Test");
    Control::SetValue( "xFontTest::Font1_10", "<jc><f:Quantico-Bold-60.pft:FF0000:EE9B01:4,4>Font Test");

    // =================================================================================================

    Control::SetValue( "xFontTest::Title2_1", "<jc><f:Roboto-Regular-20.pft:FFFFFF>Original Font");
    Control::SetValue( "xFontTest::Font2_1", "<jc><f:Shannon-60.pft>Font Test");

    Control::SetValue( "xFontTest::Title2_2", "<jc><f:Roboto-Regular-20.pft:FFFFFF>Transparency");
    Control::SetValue( "xFontTest::Font2_2", "<jc><f:Shannon-60.pft:1e90ff76>Font Test");
    Control::SetValue( "xFontTest::Font2_3", "<jc><f:Shannon-60.pft:1e90ff50>Font Test");
    Control::SetValue( "xFontTest::Font2_4", "<jc><f:Shannon-60.pft:1e90ff25>Font Test");

    Control::SetValue( "xFontTest::Title2_3", "<jc><f:Roboto-Regular-20.pft:FFFFFF>Background Offsets");
    Control::SetValue( "xFontTest::Font2_5", "<jc><f:Shannon-60.pft:FFFFFF:000000:2,2>Font Test");
    Control::SetValue( "xFontTest::Font2_6", "<jc><f:Shannon-60.pft:FFFFFF:000000:4,4>Font Test");
    Control::SetValue( "xFontTest::Font2_7", "<jc><f:Shannon-60.pft:FFFFFF:000000:6,6>Font Test");

    Control::SetValue( "xFontTest::Title2_4", "<jc><f:Roboto-Regular-20.pft:FFFFFF>Background Transparency");
    Control::SetValue( "xFontTest::Font2_8", "<jc><f:Shannon-60.pft:FF0000:FFFFFF76:5,5>Font Test");
    Control::SetValue( "xFontTest::Font2_9", "<jc><f:Shannon-60.pft:FF0000:FFFFFF60:5,5>Font Test");
    Control::SetValue( "xFontTest::Font2_10", "<jc><f:Shannon-60.pft:FF0000:FFFFFF25:5,5>Font Test");

    // =================================================================================================

    Control::SetValue( "xFontTest::Title3_1", "<jc><f:Roboto-Regular-20.pft:FFFFFF>Original Font");
    Control::SetValue( "xFontTest::Font3_1", "<jc><f:ProtestStrike-60.pft>Font Test");

    Control::SetValue( "xFontTest::Title3_2", "<jc><f:Roboto-Regular-20.pft:FFFFFF>Transparency Timers");
    Control::SetValue( "xFontTest::Font3_2", "<jc><f:ProtestStrike-60.pft:1e90ff"~$xFontTest::Timer1~">PULSE");
    Control::SetValue( "xFontTest::Font3_3", "<jc><f:ProtestStrike-60.pft:1e90ff"~$xFontTest::Timer2~">LOOP");
    Control::SetValue( "xFontTest::Font3_4", "<jc><f:ProtestStrike-60.pft:1e90ff"~$xFontTest::Timer3~">FLASH");
    Control::SetValue( "xFontTest::Font3_5", "<jc><f:ProtestStrike-60.pft:1e90ff"~$xFontTest::Timer4~">FADE");

    Control::SetValue( "xFontTest::Title3_3", "<jc><f:Roboto-Regular-20.pft:FFFFFF>Background Timers");
    Control::SetValue( "xFontTest::Font3_6", "<jc><f:ProtestStrike-60.pft:FFFFFF:9acd32"~$xFontTest::Timer5~":3,3>PULSE");
    Control::SetValue( "xFontTest::Font3_7", "<jc><f:ProtestStrike-60.pft:FFFFFF:ffa500"~$xFontTest::Timer6~":3,3>LOOP");
    Control::SetValue( "xFontTest::Font3_8", "<jc><f:ProtestStrike-60.pft:FFFFFF:1e90ff"~$xFontTest::Timer7~":3,3>FLASH");
    Control::SetValue( "xFontTest::Font3_9", "<jc><f:ProtestStrike-60.pft:FF0000:FFFFFF"~$xFontTest::Timer8~":3,3>FADE");

    // =================================================================================================

    Control::SetValue( "xFontTest::Title4_1", "<jc><f:Roboto-Regular-20.pft:FFFFFF>Stroke Colors");
    Control::SetValue( "xFontTest::Font4_1s", "<jc><f:Strada-60-2s.pft:FFFFFF:000000:2,2>Font Test");
    Control::SetValue( "xFontTest::Font4_1t", "<jc><f:Strada-60-2t.pft:9acd32>Font Test");
    Control::SetValue( "xFontTest::Font4_2s", "<jc><f:Strada-60-2s.pft:FF0000>Font Test");
    Control::SetValue( "xFontTest::Font4_2t", "<jc><f:Strada-60-2t.pft:0000FF>Font Test");

    Control::SetValue( "xFontTest::Title4_2", "<jc><f:Roboto-Regular-20.pft:FFFFFF>Original Image");
    Control::SetValue( "xFontTest::Image4_3", "<jc><b0,0:Modules/xFontTest/Images/healthbar.png>");

    Control::SetValue( "xFontTest::Title4_3", "<jc><f:Roboto-Regular-20.pft:FFFFFF>Color Overlays");
    Control::SetValue( "xFontTest::Image4_4", "<jc><b0,0:Modules/xFontTest/Images/healthbar.png:00FF00>");
    Control::SetValue( "xFontTest::Image4_5", "<jc><b0,0:Modules/xFontTest/Images/healthbar.png:FF0000>");
    Control::SetValue( "xFontTest::Image4_6", "<jc><b0,0:Modules/xFontTest/Images/healthbar.png:0000FF>");

    Control::SetValue( "xFontTest::Title4_4", "<jc><f:Roboto-Regular-20.pft:FFFFFF>Original");
    Control::SetValue( "xFontTest::Title4_5", "<jc><f:Roboto-Regular-20.pft:FFFFFF>Overlay");
    Control::SetValue( "xFontTest::Image4_7", "<jc><b0,0:Modules/xFontTest/Images/flag.png>");
    Control::SetValue( "xFontTest::Image4_8", "<jc><b0,0:Modules/xFontTest/Images/flag.png:00FF00>");
    Control::SetValue( "xFontTest::Image4_9", "<jc><b0,0:Modules/xFontTest/Images/flag.png:FF0000>");

    // =================================================================================================

    // Example 1: Implement Fade using callback feature
    if (schedule("", 0) && !$xFontTest::Timer4Started) { // Scheduler is active
        $xFontTest::Timer4Started = true;
        %control = Control::getId("xFontTest::Font3_5");
        xFont::StartTimer("xFontTest::Timer4", 0, "xFontTest::Timer4Callback", %control); // Adding a [callbackValue] is optional
        //xFont::StartTimer("xFontTest::Timer4", 0, "xFontTest::Timer4Callback"); // You can also just provide a [callbackFunc] only
    }

    // Example 2: Implement Fade without using callback feature
    %schedule = "xFont::StartTimer(\"xFontTest::Timer8\");";
    if (schedule("", 0)) { // Scheduler is active
        if (!Schedule::Check(%schedule)) {
            Schedule::Add(%schedule, 2.5);
        }
    }

    Schedule::Add("xFontTest::Update();", 0.1);

}

function xFontTest::Timer4Callback(%callbackValue) {
    Schedule::Add("xFont::StartTimer(\"xFontTest::Timer4\", 0, \"xFontTest::Timer4Callback\", \""~%callbackValue~"\");", 2.5);
}

xFontTest::Init();
