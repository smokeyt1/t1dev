xTerrain.dll for Tribes 1.40/1.41
Version 0.2
By Smokey and BOV

=======================================================================================================
About
=======================================================================================================
Plugin that fixes game crashes on high Player FOVs when using high resolution terrain textures (e.g., 256x256, 512x512).
Thanks to BOV for help identifying a fix for this issue.

Plugin also allows you to set $pref::PlayerFov up to 160 rather than the standard limit of 120.

=======================================================================================================
Details
=======================================================================================================
Tribes crashes when using high resolution terrain textures (e.g., 256x256 and 512x512) due to a bug in rendering distant terrain textures.
This typically happens when using Player FOVs greater than ~120. Plugin supports following texture sizes:

- 32x32
- 64x64
- 128x128
- 256x256
- 512x512