xEvent.dll for Tribes 1.40/1.41
Version 0.2
By Smokey


=======================================================================================================
About
=======================================================================================================
Plugin that adds additional events that can be used in scripts/HUDs, including:

- eventItemCountUpdate
- eventItemMountUpdate

=======================================================================================================
Details
=======================================================================================================

    eventItemCountUpdate(%item, %delta)
-------------------------------------------------------------------------------------------------------
    Triggered when the item count of the player changes.

    Parameters:
        %item - Item ID of the item that changed
        %delta - Numerical change in item count (positive and negative)

    Example:
        function ItemCountUpdate(%item, %delta) {
            %desc = getItemDesc(%item);
            %count = getItemCount(%desc);

            echoc(1, "[eventItemCountUpdate] => Item: ["~%item~"] Desc: ["~%desc~"] Count: [" ~ %count ~ "] Delta: [" ~ %delta ~"]");
        }
        Event::Attach(eventItemCountUpdate, ItemCountUpdate);


    eventItemMountUpdate(%slot, %item)
-------------------------------------------------------------------------------------------------------
    Triggered when the item mounted to a slot changes.

    Parameters:
        %slot - Slot number of mounted item
        %item - Item ID of the related item

    Note:
        If the item is dismounted, %item will be -1 (For example, when dropping a weapon)

    Example:
        function ItemMountUpdate(%slot, %item) {
            %desc = getItemDesc(%item);
            echoc(1, "[eventItemMountUpdate] => Item: ["~%item~"] Slot: ["~%slot~"] Desc: ["~%desc~"]");
        }
        Event::Attach(eventItemMountUpdate, ItemMountUpdate);

