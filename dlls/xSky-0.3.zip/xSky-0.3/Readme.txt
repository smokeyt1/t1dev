xSky.dll for Tribes 1.40/1.41
Version 0.3
By Smokey

=======================================================================================================
About
=======================================================================================================
Plugin that lets you change the sky texture and render properties in-game with the following functions:

    - xSky::setDML(%dmlFileName);
    - xSky::getDML();
    - xSky::setSize(%size);
    - xSky::getSize();
    - xSky::setDistance(%distance);
    - xSky::getDistance();
    - xSky::setOffset(%offset);
    - xSky::getOffset();
    - xSky::setRotation(%rotation);
    - xSky::getRotation();
    - xSky::setRotationSpeed(%speed);
    - xSky::getRotationSpeed();

=======================================================================================================
Details
=======================================================================================================

    xSky::setDML(%dmlFileName)
-------------------------------------------------------------------------------------------------------
    Changes the sky texture file in-game.

    Parameters:
        %dmlFileName - File name of the Tribe's material list file for the sky (.dml)

    Example:
        - xSky::setDML("litesky.dml");
        - xSky::setDML("lushdayclear.dml");

    Note: If the .dml file is in a volume (e.g., LushWorld.zip), that volume must be loaded.

    xSky::getDML() - Returns the current sky texture .dml file.



    xSky::setSize(%size)
-------------------------------------------------------------------------------------------------------
    Changes the sky texture size in-game.

    Parameters:
        %size - Size to render the textures. Generally values between 300-1000 are reasonable. (Min value: 1.0)

    Example:
        - xSky::setSize(450);

    xSky::getSize() - Returns the current sky size.



    xSky::setDistance(%distance)
-------------------------------------------------------------------------------------------------------
    Changes the distance from camera origin to render the sky.

    Parameters:
        %distance - Additional distance to render the sky from camera origin. Values from 0 to 700 are reasonable (can be negative). (Default: 0)

    Example:
        - xSky::setDistance(400);

    xSky::getDistance() - Returns the current additional sky distance.



    xSky::setOffset(%offset)
-------------------------------------------------------------------------------------------------------
    Changes the vertical offset of the sky panels.

    Parameters:
        %offset - Vertical (z) offset to render the sky panels. Reasonable values depend on size and distance (can be negative). (Default: 0)

    Example:
        - xSky::setOffset(100);

    xSky::getOffset() - Returns the current vertical offset.



    xSky::setRotation(%rotation)
-------------------------------------------------------------------------------------------------------
    Set the rotation of the sky band.

    Parameters:
        %rotation - Rotation in degrees of the sky band. Values from 0 to 360.

    Example:
        - xSky::setRotation(45);

    xSky::getRotation() - Returns the current sky band rotation.



    xSky::setRotationSpeed(%speed)
-------------------------------------------------------------------------------------------------------
    Sets the rotation speed of the sky band.

    Parameters:
        %speed - Rotation speed of the sky band. Values from 0 to 100 are reasonable (can be negative). (Default: 0)

    Example:
        - xSky::setRotationSpeed(20);

    xSky::getRotationSpeed() - Returns the current rotation speed.
