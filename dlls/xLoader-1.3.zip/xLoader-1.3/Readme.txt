xLoader for Tribes 1.41
Version 1.3
By Smokey

=======================================================================================================
About
=======================================================================================================
Alternative DLL loader with the following features:

- Windows: Supported on all versions of Windows without winfix / rasadhlp.dll
- Linux: Supported on Linux/Wine/Proton
- Blacklist: Functionality to disable individual plugins from loading (plugins/blacklist.ini)
- Load Timing: Ability to specify whether to load individual plugins either before or after startup/autoexec (plugins/Example.ini)
- Script Variables: $xLoader::* variables will be set to indicate the loaded / failed plugins for use in scripts
- Script Events: Event 'eventPluginsLoaded' will be triggered after the startup/autoexec process after all DLLs are loaded

=======================================================================================================
Installation
=======================================================================================================
1) INSTALL the following files to your Tribes root directory:

    Tribes/Tribes.exe (Required)
    Tribes/xLoader.dll (Required)
    Tribes/plugins/blacklist.ini (Optional)
    Tribes/plugins/Example.ini (Optional)
    Tribes/config/Modules/eventPluginsLoaded.acs.cs (Optional)

2) DELETE the following files from your Tribes root directory:

    Tribes/rasadhlp.dll

    If you do not remove rasadhlp.dll, it will be renamed to rasadhlp.dll.bak.


NOTE: The Microsoft Visual C++ Redistributable is required to be installed on Windows.

=======================================================================================================
Blacklist (plugins/blacklist.ini)
=======================================================================================================
Any DLLs listed in plugins/blacklist.ini will not be loaded by xLoader.
Allows you to temporarily disable plugins without having to delete them from the plugins folder.


=======================================================================================================
Load Timing (plugins/Example.ini)
=======================================================================================================
By default, xLoader will load DLLs at the end of the startup/autoexec process.
To load a DLL before startup/autoexec, create an individual .ini file for the DLL in the /plugins folder.
Refer to plugins/Example.ini file for further information.


=======================================================================================================
Script Variables
=======================================================================================================
$xLoader::* variables will be set to indicate the loaded / failed plugins for use in scripts.
For example, the following variables will be set:

    $xLoader::clientsky = "true"; (true = loaded, false = failed)
    $xLoader::LoDFix = "true";
    $xLoader::netset = "true";
    $xLoader::test = "false";

    $xLoader::Loaded[0] = "clientsky";
    $xLoader::Loaded[1] = "LoDFix";
    $xLoader::Loaded[2] = "netset";
    $xLoader::LoadedCount = "3";

    $xLoader::Failed[0] = "test";
    $xLoader::FailedCount = "1";

    Note: The $xLoader::DLLNAME variables will be set as the DLLs are loaded (both before and after startup/autoexec).
    The $xLoader::LoadedCount and $xLoader::FailedCount variables will be set after the startup/autoexec process once all the DLLs have been loaded.

    Note: For backwards compatibility with rasadhlp.dll, $LoaderPlugin::DLLNAME will also be set to true or false depending on whether each DLL was loaded.

=======================================================================================================
Script Events
=======================================================================================================
Event 'eventPluginsLoaded' will be triggered after the startup/autoexec process after all DLLs are loaded.
You can attach to this event and evaluate the $xLoader::* variables for scripting purposes.

Refer to config/Modules/eventPluginsLoaded.acs.cs for an example:

    function onPluginsLoaded() {
        echoc(2, "--------------------------------------");
        echoc(2, "xLoader Plugins Loaded");
        echoc(2, "--------------------------------------");
        echoc(3, "Loaded Plugins: " ~ $xLoader::LoadedCount);
        echoc(1, "Failed Plugins: " ~ $xLoader::FailedCount);
        echoc(2, "--------------------------------------");
    }

    Event::Attach(eventPluginsLoaded, onPluginsLoaded);


=======================================================================================================
Tribes.exe (Technical Details)
=======================================================================================================
Accompanying the loader is a new Tribes 1.41 executable. This executable is a patched version of the
Tribes AfterHope 1.41 exe. The only change was to rename the LoadLibraryA(ScriptGL) to LoadLibraryA(xLoader)

The original Tribes.AfterHope.1.41 exe can be sourced below:

    http://www.iateyourbaby.com/download/Tribes.AfterHope.1.41.zip
    https://web.archive.org/web/20240122224830/https://iateyourbaby.com/download/Tribes.AfterHope.1.41.zip

The changes to the executable are below:

    --------------------------------------------------------------------------------
    md5sum Tribes-1.41-AfterHope.exe Tribes-1.41-xLoader.exe
    --------------------------------------------------------------------------------
    941a5ddb40d74d51ef638899349d23a3  Tribes-1.41-AfterHope.exe
    c5bf45c27a4038fb7116bf290ac3be02  Tribes-1.41-xLoader.exe

    --------------------------------------------------------------------------------
    diff <(xxd -g1 Tribes-1.41-AfterHope.exe) <(xxd -g1 Tribes-1.41-xLoader.exe)
    --------------------------------------------------------------------------------
    157504,157505c157504,157505
    < 002673f0: 44 65 76 69 63 65 00 53 63 72 69 70 74 47 4c 2e  Device.ScriptGL.
    < 00267400: 64 6c 6c 00 4d 6f 75 73 65 00 00 00 4b 65 79 62  dll.Mouse...Keyb
    ---
    > 002673f0: 44 65 76 69 63 65 00 78 4c 6f 61 64 65 72 2e 64  Device.xLoader.d
    > 00267400: 6c 6c 00 00 4d 6f 75 73 65 00 00 00 4b 65 79 62  ll..Mouse...Keyb
