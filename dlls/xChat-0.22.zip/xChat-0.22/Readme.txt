xChat.dll for Tribes 1.41
Version 0.22
By Smokey

Thanks to -|DF|- Link, v0dka, and Thumper for testing and suggestions!

About
=======================================================================================================
Plugin that enhances the Chat HUD with a chat hider, custom fonts/icons, and additional functions.


Preferences (modify in configuration file)
=======================================================================================================
$xChat::HiderEnabled (Default: True; Will display messages for a specific period of time)
$xChat::HiderTimeout (Default: 10; Seconds to display each message)
$xChat::ScrollTimeout (Default: 5; Seconds that hider turns off when you scroll message history with PgUp/PgDn)
$xChat::ChatOnly (Default: False; Only display Global or Team chat messages. Scroll (PgUp/PgDn) to see all messages)
$xChat::HideCmdMsg (Default: True; Hide command messages at bottom of Chat HUD in playGui)
$xChat::TransChat (Default: True; Make the Chat HUD transparent)
$xChat::TransInput (Default: True; Make the Chat Input box transparent)
$xChat::IconsEnabled (Default: False; Display custom icons next to each message based on message type)

Custom fonts and icons can be configured in the configuration file.


Functions
=======================================================================================================
-------------------------------------------------------------------------------------------------------
    xChat::NewMessage(message, msgType [0-4])
-------------------------------------------------------------------------------------------------------
    Function will display a custom message to the Chat HUD. The following are the available msgTypes:

        0: SystemFont (Default: White)
        1: GameFont (Default: Red)
        2: MsgFont (Default: Yellow)
        3: TeamMsgFont (Default: Green)
        4: CommandFont (Default: Red)

    Custom fonts can be set in the dll configuration file.

    Example: xChat::NewMessage("Testing123", 3)

-------------------------------------------------------------------------------------------------------
    xChat::Clear()
-------------------------------------------------------------------------------------------------------
    Function will clear the messages in the Chat HUD.


Other
=======================================================================================================
Transparent Chat HUD and Input are included so you should be able to remove chatInput.dll and TransChat.dll.

Chat HUD scrolling (PgUp/PgDn) will temporarily disable chat hider so you can scroll the message history.
